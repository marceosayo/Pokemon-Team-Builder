function displayName() {
  let name = document.getElementById("name").value;

  if (name.trim() !== "") {
    document.getElementById(
      "trainer-name"
    ).innerHTML = `<div id="result">${name}</div><button onclick="editName()" id="edit">&#9998;</button>`;
  }
}

function editName() {
  let currentName = document.getElementById("result").innerText.replace("", "");

  document.getElementById(
    "trainer-name"
  ).innerHTML = `<input type="text" id="name" maxlength="12" value="${currentName.trim()}" /><button onclick="displayName()" id="submit">&#10003;</button>`;
}

function changeIcon(slot) {
  const select = document.querySelector(`#choice-${slot} .choice`);
  const pokemonId = select.value;
  const img = document.getElementById(`pokeball-${slot}`);

  if (pokemonId !== "-") {
    img.src = `images/${pokemonId}.gif`;
  } else {
    img.src = `images/tumblr_nu4n8oxf6b1r7tm2fo1_500.gif`;
  }
}
